# Kefirstan VTuber Android

Aurelia 3D countryball with four regional flags and a real adapted Oval Office scene.

## Build
Run `gradle --no-daemon :app:assembleDebug` with JDK 17 and Android SDK 35. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Controls
Front camera tracks face pose and eyes locally via ML Kit. Mic permission is optional. Formats: 16:9 / 9:16 / 4:3. The translucent circle hides the UI.

## Source
The original user-provided Oval Office GLB was adapted with four regional flags and no original US flag meshes. See `model-source/SOURCE_AND_LICENSE.md`. Build-time OBJ and texture data are included as Android assets.

A successful build does not prove camera tracking works on every phone. Test on device.
