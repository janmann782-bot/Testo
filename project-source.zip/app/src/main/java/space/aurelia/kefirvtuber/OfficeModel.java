package space.aurelia.kefirvtuber;

import android.content.res.AssetManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/** Loads the actual bundled Wavefront OBJ office geometry, not a painted backdrop. */
final class OfficeModel {
    static final class Part { final String material; final Mesh3D mesh;
        Part(String material, Mesh3D mesh) { this.material=material; this.mesh=mesh; }
    }
    final ArrayList<Part> parts=new ArrayList<>();
    OfficeModel(AssetManager assets) throws Exception {
        ArrayList<float[]> vertices=new ArrayList<>(); vertices.add(new float[]{0,0,0});
        Map<String, ArrayList<int[]>> faces=new LinkedHashMap<>();
        String material="wall";
        try (BufferedReader rd=new BufferedReader(new InputStreamReader(assets.open("presidential_office.obj")))) {
            String line;
            while((line=rd.readLine())!=null) {
                if(line.startsWith("v ")) {
                    String[] t=line.trim().split("\\s+");
                    vertices.add(new float[]{Float.parseFloat(t[1]),Float.parseFloat(t[2]),Float.parseFloat(t[3])});
                } else if(line.startsWith("usemtl ")) {
                    material=line.substring(7).trim();
                } else if(line.startsWith("f ")) {
                    String[] t=line.trim().split("\\s+");
                    if(t.length!=4) throw new IllegalArgumentException("Only triangle OBJ faces supported");
                    int[] triangle=new int[3];
                    for(int k=0;k<3;k++)triangle[k]=Integer.parseInt(t[k+1].split("/")[0]);
                    faces.computeIfAbsent(material,k->new ArrayList<>()).add(triangle);
                }
            }
        }
        for(Map.Entry<String, ArrayList<int[]>> item : faces.entrySet()) {
            String name=item.getKey();
            Mesh3D.Builder b=new Mesh3D.Builder();
            float minX=Float.MAX_VALUE,maxX=-Float.MAX_VALUE,minY=Float.MAX_VALUE,maxY=-Float.MAX_VALUE;
            float minZ=Float.MAX_VALUE,maxZ=-Float.MAX_VALUE;
            if(name.startsWith("flag_")||name.startsWith("shadow_")) {
                for(int[] inds:item.getValue())for(int idx:inds){float[] p=vertices.get(idx);
                    minX=Math.min(minX,p[0]);maxX=Math.max(maxX,p[0]);
                    minY=Math.min(minY,p[1]);maxY=Math.max(maxY,p[1]);
                    minZ=Math.min(minZ,p[2]);maxZ=Math.max(maxZ,p[2]);}
            }
            for(int[] inds:item.getValue()) {
                float[] a=vertices.get(inds[0]),c=vertices.get(inds[1]),d=vertices.get(inds[2]);
                float x1=c[0]-a[0],y1=c[1]-a[1],z1=c[2]-a[2];
                float x2=d[0]-a[0],y2=d[1]-a[1],z2=d[2]-a[2];
                float nx=y1*z2-z1*y2,ny=z1*x2-x1*z2,nz=x1*y2-y1*x2;
                float norm=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);norm=Math.max(norm,.000001f);
                nx/=norm;ny/=norm;nz/=norm;
                for(float[] p:new float[][]{a,c,d}) {
                    float u=(name.startsWith("flag_")||name.startsWith("shadow_"))?(p[0]-minX)/Math.max(.01f,maxX-minX):0;
                    float v=name.startsWith("flag_")?(p[1]-minY)/Math.max(.01f,maxY-minY)
                             :name.startsWith("shadow_")?(p[2]-minZ)/Math.max(.01f,maxZ-minZ):0;
                    b.vertex(p[0],p[1],p[2],nx,ny,nz,u,v);
                }
            }
            parts.add(new Part(name,b.build()));
        }
    }
}
