package space.aurelia.kefirvtuber;

/** Actual output canvas shapes, not decorative ratio labels. */
public enum FrameRatio {
    LANDSCAPE("16:9",16,9), PORTRAIT("9:16",9,16), CLASSIC("4:3",4,3);
    public final String label; public final int width,height;
    FrameRatio(String label,int width,int height){this.label=label;this.width=width;this.height=height;}
    public float aspect(){return (float)width/height;}
}
