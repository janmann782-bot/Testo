package space.aurelia.kefirvtuber;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;

/** Real triangle meshes, with normals and UVs. Coordinates follow the source Blender rig, Z forward. */
final class Mesh3D {
    final FloatBuffer data;
    final int count;
    private Mesh3D(float[] a) {
        data = ByteBuffer.allocateDirect(a.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        data.put(a).position(0);
        count=a.length/8;
    }
    static final class Builder {
        final ArrayList<Float> values=new ArrayList<>();
        void vertex(float x,float y,float z,float nx,float ny,float nz,float u,float v){
            values.add(x);values.add(y);values.add(z);values.add(nx);values.add(ny);values.add(nz);values.add(u);values.add(v);
        }
        void tri(float[] a,float[] b,float[] c,float[] n,float[][] uvs){
            vertex(a[0],a[1],a[2],n[0],n[1],n[2],uvs[0][0],uvs[0][1]);
            vertex(b[0],b[1],b[2],n[0],n[1],n[2],uvs[1][0],uvs[1][1]);
            vertex(c[0],c[1],c[2],n[0],n[1],n[2],uvs[2][0],uvs[2][1]);
        }
        Mesh3D build(){float[] a=new float[values.size()];for(int i=0;i<a.length;i++)a[i]=values.get(i);return new Mesh3D(a);}
    }
    private static void point(Builder b,float[] p,float u,float v){
        float d=(float)Math.sqrt(p[0]*p[0]+p[1]*p[1]+p[2]*p[2]);
        b.vertex(p[0],p[1],p[2],p[0]/Math.max(.001f,d),p[1]/Math.max(.001f,d),p[2]/Math.max(.001f,d),u,v);
    }
    // The Blender source has 128 longitude x 64 latitude cells and the same texcoord assignment.
    static Mesh3D countryball(){
        Builder b=new Builder();int lon=128,lat=64;
        for(int j=0;j<lat;j++) for(int i=0;i<lon;i++){
            sphereV(b,j+1,i,lat,lon);sphereV(b,j+1,i+1,lat,lon);sphereV(b,j,i+1,lat,lon);
            sphereV(b,j+1,i,lat,lon);sphereV(b,j,i+1,lat,lon);sphereV(b,j,i,lat,lon);
        }
        return b.build();
    }
    private static void sphereV(Builder b,int j,int i,int lat,int lon){
        double ph=Math.PI*j/lat,th=2*Math.PI*((double)i/lon-.5);
        float x=(float)(Math.sin(ph)*Math.sin(th)),y=(float)Math.cos(ph),z=(float)(Math.sin(ph)*Math.cos(th));
        // glTF/Blender vertical-axis convention: top row of flag at V=1.
        point(b,new float[]{x,y,z},(float)i/lon,1f-(float)j/lat);
    }
    static Mesh3D discOnBall(float cx,float cy,float w,float h,float depth,int divisions){
        Builder b=new Builder();
        for(int i=0;i<divisions;i++){
            discV(b,cx,cy,w,h,depth,0,0);
            double a=i*2*Math.PI/divisions,bb=(i+1)*2*Math.PI/divisions;
            discV(b,cx,cy,w,h,depth,(float)Math.cos(a),(float)Math.sin(a));
            discV(b,cx,cy,w,h,depth,(float)Math.cos(bb),(float)Math.sin(bb));
        }
        return b.build();
    }
    private static void discV(Builder b,float cx,float cy,float w,float h,float dep,float xx,float yy){
        float x=cx+w*xx,y=cy+h*yy;
        float z=(float)Math.sqrt(Math.max(.005f,1-x*x-y*y))+dep;
        b.vertex(w*xx,h*yy,z-(float)Math.sqrt(Math.max(.005f,1-cx*cx-cy*cy)),0,0,1,(xx+1)/2,(1-yy)/2);
    }
    static Mesh3D unitCube(){
        Builder b=new Builder();
        face(b,new float[]{0,0,1},new float[]{-.5f,-.5f,.5f},new float[]{.5f,-.5f,.5f},new float[]{.5f,.5f,.5f},new float[]{-.5f,.5f,.5f});
        face(b,new float[]{0,0,-1},new float[]{.5f,-.5f,-.5f},new float[]{-.5f,-.5f,-.5f},new float[]{-.5f,.5f,-.5f},new float[]{.5f,.5f,-.5f});
        face(b,new float[]{1,0,0},new float[]{.5f,-.5f,.5f},new float[]{.5f,-.5f,-.5f},new float[]{.5f,.5f,-.5f},new float[]{.5f,.5f,.5f});
        face(b,new float[]{-1,0,0},new float[]{-.5f,-.5f,-.5f},new float[]{-.5f,-.5f,.5f},new float[]{-.5f,.5f,.5f},new float[]{-.5f,.5f,-.5f});
        face(b,new float[]{0,1,0},new float[]{-.5f,.5f,.5f},new float[]{.5f,.5f,.5f},new float[]{.5f,.5f,-.5f},new float[]{-.5f,.5f,-.5f});
        face(b,new float[]{0,-1,0},new float[]{-.5f,-.5f,-.5f},new float[]{.5f,-.5f,-.5f},new float[]{.5f,-.5f,.5f},new float[]{-.5f,-.5f,.5f});
        return b.build();
    }
    static Mesh3D quad(){
        Builder b=new Builder();face(b,new float[]{0,0,1},new float[]{-.5f,-.5f,0},new float[]{.5f,-.5f,0},new float[]{.5f,.5f,0},new float[]{-.5f,.5f,0});return b.build();
    }
    private static void face(Builder b,float[] n,float[] a,float[] c,float[] d,float[] e){
        float[][] uv={{0,1},{1,1},{1,0},{0,0}};
        b.tri(a,c,d,n,new float[][]{uv[0],uv[1],uv[2]});b.tri(a,d,e,n,new float[][]{uv[0],uv[2],uv[3]});
    }
    // Solid 3D hair: multilayer crown cap (not a billboard), with an inner scalp cavity.
    static Mesh3D hairCap(){
        Builder b=new Builder(); int rings=20, around=80;
        for(int j=0;j<rings;j++) for(int i=0;i<around;i++){
            capV(b,j,i,rings,around);capV(b,j+1,i,rings,around);capV(b,j+1,i+1,rings,around);
            capV(b,j,i,rings,around);capV(b,j+1,i+1,rings,around);capV(b,j,i+1,rings,around);
        }
        return b.build();
    }
    private static void capV(Builder b,int j,int i,int rings,int around){
        double phi=.015+(1.2-.015)*j/rings,theta=2*Math.PI*i/around;
        float r=1.07f+.022f*(float)Math.sin(theta*11), x=(float)(r*Math.sin(phi)*Math.cos(theta));
        float y=(float)(r*Math.cos(phi));float z=(float)(r*Math.sin(phi)*Math.sin(theta));
        point(b,new float[]{x,y,z},i/(float)around,j/(float)rings);
    }
    // Curving locks are tapered tubes with 3D cross sections, from side of crown to jaw.
    static Mesh3D hairLock(int side,int variant){
        Builder b=new Builder();int levels=32,sides=12;
        for(int j=0;j<levels;j++)for(int i=0;i<sides;i++){
            lockV(b,side,variant,j,i,levels,sides);lockV(b,side,variant,j+1,i,levels,sides);lockV(b,side,variant,j+1,i+1,levels,sides);
            lockV(b,side,variant,j,i,levels,sides);lockV(b,side,variant,j+1,i+1,levels,sides);lockV(b,side,variant,j,i+1,levels,sides);
        }
        return b.build();
    }
    private static void lockV(Builder b,int side,int variant,int j,int i,int levels,int sides){
        float t=j/(float)levels;double a=i*2*Math.PI/sides;
        float x=side*(.69f + variant*.115f +.18f*t-.07f*(float)Math.sin(t*Math.PI));
        float y=.69f -1.26f*t + variant*.14f;
        float z=.50f+ .18f*(float)Math.sin(t*Math.PI)+(.05f*variant);
        float radius=(.16f+.025f*variant)*(float)Math.pow(Math.sin(.25+2.65*t),.6);
        float dx=radius*(float)Math.cos(a),dz=radius*.85f*(float)Math.sin(a);
        float xx=x+dx, zz=z+dz; b.vertex(xx,y,zz,dx/(radius+.0001f),-.10f,dz/(radius+.0001f),i/(float)sides,t);
    }
    void draw(int aPos,int aNormal,int aUv){
        data.position(0);GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,32,data);
        data.position(3);GLES20.glVertexAttribPointer(aNormal,3,GLES20.GL_FLOAT,false,32,data);
        data.position(6);GLES20.glVertexAttribPointer(aUv,2,GLES20.GL_FLOAT,false,32,data);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,count);
    }
}
